#Question 2
# European Call Option Valuation under Uniform Price Change

set.seed(42)
S0 <- 100        # Initial stock price
K <- 105         # Strike price
n_days <- 10     # Time to maturity
n_sim <- 10000   # Number of simulations

# Define support of Uniform[-a, a] where E[|X|] = 1 => a = 2
a <- 2

# Simulate price paths
payoffs <- numeric(n_sim)

for (i in 1:n_sim) {
  # Generate 10 daily price changes from Uniform[-2, 2]
  daily_changes <- runif(n_days, -a, a)
  
  # Final stock price after 10 days
  ST <- S0 + sum(daily_changes)
  
  # European call payoff
  payoffs[i] <- max(ST - K, 0)
}

# Estimate fair value of the option
fair_value <- mean(payoffs)
cat("Estimated fair value of the call option:", fair_value, "\n")



#Result - Estimated fair value of the call option: 0.1390248175255023 


#Questin 3
# Buffon's Needle Simulation in R

set.seed(123)  # For reproducibility
N <- 10000     # Number of needle drops
d <- 1         # Distance between lines
l <- 1         # Length of needle

# Generate N random angles θ ~ Uniform(0, π/2)
theta <- runif(N, 0, pi/2)

# Generate N random distances x ~ Uniform(0, d/2)
x <- runif(N, 0, d/2)

# A crossing occurs if (l/2) * sin(theta) >= x
crossings <- sum((l/2) * sin(theta) >= x)

# Estimate of π
pi_estimate <- (2 * N) / (d * crossings)
cat("Estimated value of pi:", pi_estimate, "\n")

# Plot convergence (optional)
pi_values <- numeric(N)
count <- 0
for (i in 1:N) {
  if ((l/2) * sin(theta[i]) >= x[i]) {
    count <- count + 1
  }
  pi_values[i] <- (2 * i) / (d * count)
}

# Plot with log scale
plot(1:N, pi_values, type = "l", col = "blue",
     log = "x", xlab = "Number of simulations (log scale)",
     ylab = "Estimated π", main = "Convergence of π Estimate")
abline(h = pi, col = "red", lty = 2)
legend("topright", legend = c("Estimate", "True π"), col = c("blue", "red"), lty = c(1,2))
